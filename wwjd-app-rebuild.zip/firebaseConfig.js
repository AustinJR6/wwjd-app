// firebaseConfig.js
import { initializeApp } from 'firebase/app'
import { getFirestore } from 'firebase/firestore'
import { getAuth } from 'firebase/auth' // 👈 Add this line

const firebaseConfig = {
  apiKey: "AIzaSyAeitpWVBGmPZJ540vgCNZpte_05LPx0Z8",
  authDomain: "wwjd-app.firebaseapp.com",
  projectId: "wwjd-app",
  storageBucket: "wwjd-app.firebasestorage.app",
  messagingSenderId: "402334171334",
  appId: "1:402334171334:web:69a89d40732306572757c7",
  measurementId: "G-20W5BML7DM"
}

const app = initializeApp(firebaseConfig)
export const db = getFirestore(app)
export const auth = getAuth(app) // 👈 Export Firebase Auth
