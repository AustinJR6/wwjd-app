import React, { useState } from 'react'
import { View, Text, TextInput, Button, StyleSheet, ScrollView, Alert } from 'react-native'
import {
  getSubscriptionStatus,
  getTokenCount,
  consumeToken,
  canUseFreeAsk,
  useFreeAsk
} from '../utils/TokenManager'
import ScreenContainer from '../components/theme/ScreenContainer'
import { theme } from '../components/theme/theme'

const OPENAI_API_KEY = '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'

export default function ConfessionalScreen({ navigation }) {
  const [confession, setConfession] = useState('')
  const [response, setResponse] = useState('')
  const [loading, setLoading] = useState(false)
  const [released, setReleased] = useState(false)

  const handleConfess = async () => {
    if (!confession.trim()) return
    setLoading(true)
    setResponse('')

    try {
      const isSubscribed = await getSubscriptionStatus()
      const canUseFree = await canUseFreeAsk()
      const tokens = await getTokenCount()

      if (!isSubscribed && !canUseFree && tokens < 1) {
        setResponse("You've already used your free confessional today. Please upgrade or buy more tokens.")
        return
      }

      if (!isSubscribed) {
        if (canUseFree) {
          await useFreeAsk()
        } else {
          await consumeToken()
        }
      }

      const payload = {
        model: 'gpt-3.5-turbo',
        messages: [
          {
            role: 'system',
            content: `You are a gentle, Christ-modeled confessional guide. Receive the user's confession with compassion and grace. Offer forgiveness, wisdom, and encouragement rooted in scripture. End with a message of peace.`
          },
          {
            role: 'user',
            content: confession
          }
        ],
        temperature: 0.8
      }

      const res = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${OPENAI_API_KEY}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(payload)
      })

      const data = await res.json()
      const message = data.choices?.[0]?.message?.content
      setResponse(message || 'You are forgiven. Walk in grace.')
    } catch (err) {
      console.error('Confessional error:', err)
      setResponse('Something went wrong. Please try again later.')
    } finally {
      setLoading(false)
    }
  }

  const handleRelease = () => {
    setConfession('')
    setResponse('')
    setReleased(true)
    Alert.alert('Released', 'Your confession has been lifted to the light and forgotten.')
  }

  return (
    <ScreenContainer>
      <ScrollView contentContainerStyle={styles.scroll}>
        {!released ? (
          <>
            <Text style={styles.title}>Confessional</Text>
            <TextInput
              style={styles.input}
              multiline
              placeholder="Speak what's on your heart…"
              placeholderTextColor={theme.colors.fadedText}
              value={confession}
              onChangeText={setConfession}
              editable={!loading}
            />
            <Button
              title={loading ? 'Receiving Grace...' : 'Confess'}
              onPress={handleConfess}
              disabled={loading || !confession.trim()}
            />
            {response ? (
              <View style={styles.responseBox}>
                <Text style={styles.response}>{response}</Text>
                <Button title="Release & Return" onPress={handleRelease} />
              </View>
            ) : null}
          </>
        ) : (
          <View style={styles.releaseBox}>
            <Text style={styles.peace}>🕊️ Your confession is gone. You are at peace.</Text>
            <Button title="Back to Home" onPress={() => navigation.navigate('Home')} />
          </View>
        )}
      </ScrollView>
    </ScreenContainer>
  )
}

const styles = StyleSheet.create({
  scroll: {
    flexGrow: 1,
    justifyContent: 'center'
  },
  title: {
    fontSize: 26,
    fontWeight: 'bold',
    marginBottom: 16,
    textAlign: 'center',
    color: theme.colors.text
  },
  input: {
    borderColor: theme.colors.border,
    borderWidth: 1,
    padding: 12,
    borderRadius: 10,
    marginBottom: 20,
    textAlignVertical: 'top',
    backgroundColor: theme.colors.surface,
    color: theme.colors.text,
    minHeight: 120
  },
  responseBox: {
    marginTop: 24,
    padding: 16,
    borderRadius: 8,
    backgroundColor: theme.colors.surface
  },
  response: {
    fontSize: 16,
    lineHeight: 22,
    color: theme.colors.text,
    marginBottom: 12
  },
  releaseBox: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20
  },
  peace: {
    fontSize: 18,
    marginBottom: 24,
    fontStyle: 'italic',
    color: theme.colors.primary,
    textAlign: 'center'
  }
})

