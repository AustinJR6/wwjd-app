import React, { useState } from 'react'
import { View, Text, Button, StyleSheet, Alert, Linking } from 'react-native'
import { useUser } from '../hooks/useUser'
import ScreenContainer from '../components/theme/ScreenContainer'
import { theme } from '../components/theme/theme'

export default function UpgradeScreen({ navigation }) {
  const [loading, setLoading] = useState(false)
  const { user } = useUser()

  const handleUpgrade = async () => {
    if (!user) return

    setLoading(true)

    try {
      const res = await fetch('https://us-central1-wwjd-app.cloudfunctions.net/createCheckoutSession', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          uid: user.uid,            // ✅ Pass UID here for webhook
          type: 'subscription'
        })
      })

      const rawText = await res.text()
      console.log('🔥 WWJD+ raw response:', rawText)
      const data = JSON.parse(rawText)

      if (data.url) {
        Linking.openURL(data.url)
      } else {
        Alert.alert('Error', 'Something went wrong. Please try again.')
      }
    } catch (err) {
      console.error('WWJD+ Subscription Error:', err)
      Alert.alert('Subscription Failed', 'We could not start the upgrade. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <ScreenContainer>
      <View style={styles.content}>
        <Text style={styles.title}>WWJD+ Membership</Text>
        <Text style={styles.subtitle}>Experience the full blessing</Text>

        <View style={styles.benefitsBox}>
          <Text style={styles.benefit}>✅ Unlimited daily WWJD questions</Text>
          <Text style={styles.benefit}>✅ Full Confessional access</Text>
          <Text style={styles.benefit}>✅ Personalized journaling prompts</Text>
          <Text style={styles.benefit}>✅ Early access to new features</Text>
        </View>

        <Text style={styles.price}>$9.99 / month</Text>

        <View style={styles.buttonWrap}>
          <Button title="Join WWJD+" onPress={handleUpgrade} disabled={loading} />
        </View>

        <View style={styles.buttonWrap}>
          <Button title="Back to Home" onPress={() => navigation.navigate('Home')} />
        </View>
      </View>
    </ScreenContainer>
  )
}

const styles = StyleSheet.create({
  content: {
    flex: 1,
    justifyContent: 'center'
  },
  title: {
    fontSize: 26,
    fontWeight: 'bold',
    textAlign: 'center',
    color: theme.colors.primary,
    marginBottom: 8
  },
  subtitle: {
    fontSize: 16,
    textAlign: 'center',
    marginBottom: 24,
    color: theme.colors.text
  },
  benefitsBox: {
    marginBottom: 24,
    paddingHorizontal: 8
  },
  benefit: {
    fontSize: 16,
    marginBottom: 8,
    color: theme.colors.text
  },
  price: {
    fontSize: 20,
    fontWeight: '600',
    textAlign: 'center',
    marginBottom: 24,
    color: theme.colors.accent
  },
  buttonWrap: {
    marginVertical: 12,
    alignItems: 'center'
  }
})
