// ChallengeScreen.tsx (cleaned for frontend)
import React, { useEffect, useState } from 'react'
import { View, Text, ActivityIndicator, Button, StyleSheet, ScrollView, Alert } from 'react-native'
import ScreenContainer from '../components/theme/ScreenContainer'
import { theme } from '../components/theme/theme'
import { doc, getDoc, setDoc, serverTimestamp } from 'firebase/firestore'
import { db, auth } from '../firebaseConfig'
import { getTokenCount, setTokenCount } from '../utils/TokenManager'

export default function ChallengeScreen({ navigation }) {
  const [challenge, setChallenge] = useState('')
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [skipLoading, setSkipLoading] = useState(false)
  const todayId = new Date().toISOString().split('T')[0]
  const ref = doc(db, 'dailyChallenges', todayId)

  const fetchChallenge = async () => {
    setLoading(true)
    setError('')
    try {
      const snap = await getDoc(ref)
      if (snap.exists()) {
        const data = snap.data()
        const createdAt = data.createdAt?.toDate?.()
        if (createdAt) {
          const createdId = createdAt.toISOString().split('T')[0]
          if (createdId === todayId) {
            setChallenge(data.text)
            return
          }
        }
      }
      await generateNewChallenge()
    } catch (err) {
      console.error('❌ Challenge Load Error:', err)
      setError('Could not load challenge. Please try again later.')
    } finally {
      setLoading(false)
    }
  }

  const generateNewChallenge = async (markSkipped = false) => {
    try {
      const response = await fetch(
        'https://us-central1-wwjd-app.cloudfunctions.net/askGemini',
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            prompt: `You are a compassionate, Christ-centered spiritual guide. Speak with the warmth and encouragement of a preacher. Provide today's daily challenge to help someone walk more like Jesus. The challenge should be heartfelt, inspiring, and no more than 60 words.`
          })
        }
      )
  
      if (!response.ok) {
        const errorText = await response.text()
        console.error(`❌ Gemini HTTP Error: ${response.status} - ${errorText}`)
        throw new Error(`HTTP error ${response.status}`)
      }
  
      const data = await response.json()
      console.log('🌟 Gemini Response:', data)
  
      const text = data.response || 'Today, reflect on your words. Speak only kindness and truth.'
  
      await setDoc(ref, {
        text,
        createdAt: serverTimestamp(),
        skipped: markSkipped
      })
  
      setChallenge(text)
    } catch (err) {
      console.error('❌ Gemini Challenge Error:', err)
      setError('Could not generate a new challenge.')
    }
  }
  

  const handleSkip = async () => {
    setSkipLoading(true)
    const user = auth.currentUser
    if (!user) return

    try {
      const userRef = doc(db, 'users', user.uid)
      const userSnap = await getDoc(userRef)
      const userData = userSnap.data() || {}
      const lastSkip = userData.lastFreeSkip?.toDate?.()
      const now = new Date()
      const sevenDays = 7 * 24 * 60 * 60 * 1000

      const canSkipFree = !lastSkip || (now.getTime() - lastSkip.getTime() > sevenDays)

      if (canSkipFree) {
        await setDoc(userRef, { lastFreeSkip: serverTimestamp(), skipTokensUsed: 0 }, { merge: true })
        await generateNewChallenge(true)
      } else {
        const skipsUsed = userData.skipTokensUsed || 0
        const cost = Math.pow(2, skipsUsed + 1)
        const tokens = await getTokenCount()

        Alert.alert(
          `Use ${cost} Tokens to Skip?`,
          `You have used your free skip this week. This skip will cost ${cost} tokens. Continue?`,
          [
            { text: 'Cancel', style: 'cancel' },
            {
              text: 'Confirm',
              onPress: async () => {
                if (tokens >= cost) {
                  await setTokenCount(tokens - cost)
                  await setDoc(userRef, { skipTokensUsed: skipsUsed + 1 }, { merge: true })
                  await generateNewChallenge(true)
                } else {
                  Alert.alert('Insufficient Tokens', 'You do not have enough tokens to skip.')
                }
              }
            }
          ]
        )
      }
    } catch (err) {
      console.error('❌ Skip Error:', err)
    } finally {
      setSkipLoading(false)
    }
  }

  useEffect(() => {
    fetchChallenge()
  }, [])

  return (
    <ScreenContainer>
      <ScrollView contentContainerStyle={styles.container}>
        <Text style={styles.title}>Today’s Challenge</Text>

        {loading ? (
          <ActivityIndicator size="large" color={theme.colors.primary} />
        ) : error ? (
          <Text style={styles.error}>{error}</Text>
        ) : (
          <Text style={styles.body}>{challenge}</Text>
        )}

        <View style={styles.buttonWrap}>
          <Button title="Back to Home" onPress={() => navigation.navigate('Home')} />
        </View>

        <View style={styles.buttonWrap}>
          <Button
            title={skipLoading ? 'Skipping...' : 'Skip Today’s Challenge'}
            onPress={handleSkip}
            disabled={skipLoading || loading}
          />
        </View>
      </ScrollView>
    </ScreenContainer>
  )
}

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 32
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    color: theme.colors.primary,
    textAlign: 'center'
  },
  body: {
    fontSize: 18,
    color: theme.colors.text,
    marginHorizontal: 16,
    marginBottom: 32,
    textAlign: 'center'
  },
  error: {
    color: theme.colors.danger,
    marginBottom: 24
  },
  buttonWrap: {
    marginTop: 12,
    width: 200
  }
})