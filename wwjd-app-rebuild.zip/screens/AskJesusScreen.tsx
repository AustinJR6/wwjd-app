// AskJesusScreen.tsx
import React, { useState } from 'react'
import {
  View,
  Text,
  TextInput,
  Button,
  ActivityIndicator,
  StyleSheet,
  Alert,
  ScrollView
} from 'react-native'
import { doc, getDoc, setDoc, serverTimestamp } from 'firebase/firestore'
import { auth, db } from '../firebaseConfig'
import ScreenContainer from '../components/theme/ScreenContainer'
import { theme } from '../components/theme/theme'
import { getTokenCount, setTokenCount } from '../utils/TokenManager'

export default function AskJesusScreen() {
  const [question, setQuestion] = useState('')
  const [answer, setAnswer] = useState('')
  const [loading, setLoading] = useState(false)

  const handleAsk = async () => {
    if (!question.trim()) {
      Alert.alert('Please enter a question.')
      return
    }

    const user = auth.currentUser
    if (!user) return

    setLoading(true)
    setAnswer('')
    const userRef = doc(db, 'users', user.uid)
    const userSnap = await getDoc(userRef)
    const userData = userSnap.data() || {}
    const lastAsk = userData.lastFreeAsk?.toDate?.()
    const now = new Date()
    const sevenDays = 7 * 24 * 60 * 60 * 1000
    const canAskFree = !lastAsk || now.getTime() - lastAsk.getTime() > sevenDays

    const cost = 5

    if (!canAskFree) {
      const tokens = await getTokenCount()
      if (tokens < cost) {
        Alert.alert(
          'Not Enough Tokens',
          `You need ${cost} tokens to ask again.`
        )
        setLoading(false)
        return
      }

      const confirmed = await new Promise((resolve) => {
        Alert.alert(
          `Use ${cost} Tokens?`,
          'You’ve already used your free ask this week. Use tokens to ask again?',
          [
            { text: 'Cancel', onPress: () => resolve(false), style: 'cancel' },
            { text: 'Yes', onPress: () => resolve(true) }
          ]
        )
      })

      if (!confirmed) {
        setLoading(false)
        return
      }

      await setTokenCount(tokens - cost)
    } else {
      await setDoc(userRef, { lastFreeAsk: serverTimestamp() }, { merge: true })
    }

    try {
      const response = await fetch('https://us-central1-wwjd-app.cloudfunctions.net/askGemini', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: `You are a warm, compassionate, Christ-centered guide. Respond to the following question with love, scripture when relevant, and thoughtful insight, as if you were Jesus helping someone grow in faith.\n\nQuestion: ${question}`
        })
      })

      const data = await response.json()
      setAnswer(data.response || 'I am always with you. Trust in Me.')
    } catch (err) {
      console.error('❌ AskJesus error:', err)
      Alert.alert('Error', 'Could not get a response. Please try again later.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <ScreenContainer>
      <ScrollView contentContainerStyle={styles.container}>
        <Text style={styles.title}>Ask for Guidance</Text>
        <TextInput
          style={styles.input}
          placeholder="What's on your heart?"
          value={question}
          onChangeText={setQuestion}
          multiline
        />
        <View style={styles.buttonWrap}>
          <Button title="Ask" onPress={handleAsk} disabled={loading} />
        </View>
        {loading && <ActivityIndicator size="large" color={theme.colors.primary} />}
        {answer ? <Text style={styles.answer}>{answer}</Text> : null}
      </ScrollView>
    </ScreenContainer>
  )
}

const styles = StyleSheet.create({
  container: {
    padding: 24,
    justifyContent: 'center',
    alignItems: 'center'
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: theme.colors.primary,
    marginBottom: 16
  },
  input: {
    borderWidth: 1,
    borderColor: theme.colors.border,
    borderRadius: 8,
    padding: 12,
    width: '100%',
    minHeight: 100,
    marginBottom: 16,
    textAlignVertical: 'top',
    backgroundColor: '#fff'
  },
  buttonWrap: {
    marginVertical: 12,
    width: '100%'
  },
  answer: {
    marginTop: 24,
    fontSize: 16,
    color: theme.colors.text,
    textAlign: 'center'
  }
})
