import React, { useEffect, useState } from 'react'
import { View, Text, StyleSheet, ActivityIndicator, Button } from 'react-native'
import { Calendar } from 'react-native-calendars'
import { db } from '../firebaseConfig'
import { collection, getDocs, setDoc, doc, serverTimestamp } from 'firebase/firestore'
import ScreenContainer from '../components/theme/ScreenContainer'
import { theme } from '../components/theme/theme'

const todayId = new Date().toISOString().split('T')[0]

export default function StreakScreen({ navigation }) {
  const [markedDates, setMarkedDates] = useState<{ [key: string]: any }>({})
  const [loading, setLoading] = useState(true)
  const [streak, setStreak] = useState(0)

  useEffect(() => {
    async function loadCompleted() {
      try {
        const snap = await getDocs(collection(db, 'completedChallenges'))
        const dates = snap.docs.map(d => d.id)

        const marks: any = {}
        let todayCompleted = false

        dates.forEach(date => {
          const isToday = date === todayId
          if (isToday) todayCompleted = true

          marks[date] = {
            selected: true,
            selectedColor: isToday ? '#ffffff' : '#FFD700', // white today, gold others
            selectedTextColor: isToday ? '#000000' : '#000000'
          }
        })

        setMarkedDates(marks)

        let count = 0
        for (let i = 0; ; i++) {
          const d = new Date()
          d.setDate(d.getDate() - i)
          const key = d.toISOString().split('T')[0]
          if (dates.includes(key)) count++
          else break
        }
        setStreak(count)
      } catch (err) {
        console.error('Error loading streak data:', err)
      } finally {
        setLoading(false)
      }
    }
    loadCompleted()
  }, [])

  const markToday = async () => {
    try {
      await setDoc(doc(db, 'completedChallenges', todayId), {
        completedAt: serverTimestamp()
      })
      navigation.replace('Streak')
    } catch (err) {
      console.error('Error marking challenge:', err)
    }
  }

  if (loading) {
    return (
      <ScreenContainer>
        <View style={styles.center}>
          <ActivityIndicator size="large" color={theme.colors.primary} />
        </View>
      </ScreenContainer>
    )
  }

  return (
    <ScreenContainer>
      <View style={styles.content}>
        <Text style={styles.header}>Grace Streak Tracker</Text>
        <Text style={styles.subheader}>Current Streak: {streak} day{streak === 1 ? '' : 's'}</Text>

        <Calendar
          markedDates={markedDates}
          theme={{
            backgroundColor: theme.colors.background,
            calendarBackground: theme.colors.surface,
            textSectionTitleColor: theme.colors.text,
            dayTextColor: theme.colors.text,
            monthTextColor: theme.colors.primary,
            arrowColor: theme.colors.primary,
            todayTextColor: theme.colors.text,
            selectedDayTextColor: '#000000',
            selectedDayBackgroundColor: '#FFD700'
          }}
        />

        <View style={styles.buttonWrap}>
          <Button title="I did the challenge today" onPress={markToday} />
        </View>

        <Button title="Back to Home" onPress={() => navigation.navigate('Home')} />
      </View>
    </ScreenContainer>
  )
}

const styles = StyleSheet.create({
  content: {
    flex: 1,
    paddingVertical: theme.spacing.lg
  },
  center: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center'
  },
  header: {
    fontSize: 24,
    fontWeight: 'bold',
    color: theme.colors.primary,
    marginBottom: 8,
    textAlign: 'center'
  },
  subheader: {
    fontSize: 16,
    marginBottom: 16,
    textAlign: 'center',
    color: theme.colors.text
  },
  buttonWrap: {
    marginVertical: 16,
    alignItems: 'center'
  }
})
