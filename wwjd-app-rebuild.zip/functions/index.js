const functions = require('firebase-functions');
const logger = require('firebase-functions/logger');
const admin = require('firebase-admin');
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY || functions.config().stripe.secret_key);
const { VertexAI } = require('@google-cloud/vertexai');

admin.initializeApp();

// ✅ Stripe Webhook (v1)
exports.handleStripeWebhook = functions.https.onRequest(async (req, res) => {
  const endpointSecret = process.env.STRIPE_WEBHOOK_SECRET || functions.config().stripe.webhook_secret;
  let event;

  try {
    const sig = req.headers['stripe-signature'];
    event = stripe.webhooks.constructEvent(req.rawBody, sig, endpointSecret);
  } catch (err) {
    logger.error('Stripe webhook signature error:', err);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  if (event.type === 'checkout.session.completed') {
    const session = event.data.object;
    const uid = session.metadata?.uid;

    if (session.mode === 'subscription' && uid) {
      try {
        await admin.firestore().collection('users').doc(uid).set(
          { isSubscribed: true },
          { merge: true }
        );
        logger.log(`✅ Updated subscription for user ${uid}`);
      } catch (err) {
        logger.error('❌ Firestore update failed:', err);
        return res.sendStatus(500);
      }
    }
  }

  res.sendStatus(200);
});

// ✅ Stripe Checkout Session Creator (v1)
exports.createCheckoutSession = functions.https.onRequest(async (req, res) => {
  if (req.method !== 'POST') return res.status(405).send('Method Not Allowed');

  const { uid, type, amount } = req.body;

  try {
    const successUrl = process.env.SUCCESS_URL || functions.config().urls.success;
    const cancelUrl = process.env.CANCEL_URL || functions.config().urls.cancel;

    let session;

    if (type === 'subscription') {
      session = await stripe.checkout.sessions.create({
        payment_method_types: ['card'],
        mode: 'subscription',
        line_items: [{
          price: process.env.STRIPE_SUBSCRIPTION_PRICE_ID || functions.config().stripe.subscription_price_id,
          quantity: 1
        }],
        success_url: successUrl,
        cancel_url: cancelUrl,
        metadata: { uid }
      });
    } else if (type === 'one-time') {
      const displayAmount = parseFloat(amount || 5);
      session = await stripe.checkout.sessions.create({
        payment_method_types: ['card'],
        mode: 'payment',
        line_items: [{
          price_data: {
            currency: 'usd',
            unit_amount: displayAmount * 100,
            product_data: { name: 'WWJD Donation' }
          },
          quantity: 1
        }],
        success_url: successUrl,
        cancel_url: cancelUrl,
        metadata: { uid }
      });
    } else {
      return res.status(400).send('Invalid type');
    }

    return res.json({ url: session.url });
  } catch (err) {
    logger.error('❌ Stripe Checkout error:', err.message);
    res.status(500).send(`Internal Server Error: ${err.message}`);
  }
});

// ✅ Gemini integration (v1)
exports.askGemini = functions.https.onRequest(async (req, res) => {
  try {
    const prompt = req.body.prompt || "Hello, who are you?";

    const vertex_ai = new VertexAI({ project: 'wwjd-app', location: 'us-central1' });
    const generativeModel = vertex_ai.preview.getGenerativeModel({
      model: 'gemini-pro',
      generationConfig: {
        temperature: 0.7,
        maxOutputTokens: 300
      },
      safetySettings: [
        { category: 'HARM_CATEGORY_DEROGATORY', threshold: 3 },
        { category: 'HARM_CATEGORY_VIOLENCE', threshold: 3 },
        { category: 'HARM_CATEGORY_SEXUAL', threshold: 3 },
        { category: 'HARM_CATEGORY_MEDICAL', threshold: 3 },
        { category: 'HARM_CATEGORY_DANGEROUS', threshold: 3 }
      ]
    });

    const result = await generativeModel.generateContent({
      contents: [{ role: 'user', parts: [{ text: prompt }] }]
    });

    const text = result.response?.candidates?.[0]?.content?.parts?.[0]?.text || 'Could not generate challenge.';
    logger.log('🌟 Gemini result:', text);

    res.json({ response: text });
  } catch (err) {
    logger.error("❌ Gemini function error:", err);
    res.status(500).send("Gemini failed");
  }
});
